/**
 * AviatorGame.jsx — Professional Autonomous Aviator Crash Game
 *
 * Design Reference: Spribe Aviator
 * - Dark navy theme with neon green/red accents
 * - Small red plane flying across graph
 * - Glass morphism bet panels
 * - Professional gaming aesthetic
 *
 * Autonomous Mode:
 * - The game runs entirely client-side (no admin panel needed)
 * - One client's browser acts as "leader" and broadcasts game state
 * - All other clients receive broadcasts and sync automatically
 * - Falls back gracefully if Supabase DB tables don't exist yet
 */

import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useToast } from '../../components/ui/Toast'
import { ChevronLeft } from 'lucide-react'
import { supabaseAnon } from '../../lib/supabase'
import {
  subscribeToGameBroadcast,
  subscribeToRoundBroadcast,
  unsubscribe,
  getRecentCrashes,
  getUserBetHistory,
  placeBet as apiPlaceBet,
  cashoutBet as apiCashoutBet,
  generateCrashPoint,
  generateBotBetAmount,
  generateBotAutoCashout,
  getRandomBotName,
  getManualCrash,
  clearManualCrash,
  getGameSettingsLocal,
  broadcastLiveHE,
  updateHouseEdgePool,
  broadcastGameState,
  getSettingsFromDB,
  checkManualCrash,
  broadcastLiveHEMetrics,
} from '../../api/aviator'

const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Exo+2:wght@400;500;600;700;800;900&display=swap');

  * { box-sizing: border-box; }

  .av-root {
    --bg-primary: #0c1220;
    --bg-secondary: #0f1929;
    --bg-panel: rgba(15,25,41,0.88);
    --border: rgba(255,255,255,0.06);
    --border-active: rgba(255,255,255,0.12);
    --green: #00e887;
    --green-dim: rgba(0,232,135,0.15);
    --green-border: rgba(0,232,135,0.3);
    --red: #ff4d4d;
    --red-dim: rgba(255,77,77,0.15);
    --yellow: #ffd600;
    --text: #ffffff;
    --text-sec: rgba(255,255,255,0.5);
    font-family: 'Inter','Exo 2',-apple-system,BlinkMacSystemFont,sans-serif;
  }

  /* Loading */
  .av-loading {
    position:fixed;inset:0;z-index:200;
    background:var(--bg-primary);
    display:flex;flex-direction:column;align-items:center;justify-content:center;
  }
  .av-loading-icon {
    width:72px;height:72px;border-radius:18px;
    background:linear-gradient(135deg,#ff4d4d,#ff8c00);
    display:flex;align-items:center;justify-content:center;
    box-shadow:0 0 50px rgba(255,77,77,0.4);margin-bottom:28px;
  }
  .av-loading-title {
    font-family:'Exo 2',sans-serif;font-size:38px;font-weight:900;
    color:var(--text);letter-spacing:.15em;text-transform:uppercase;margin:0 0 6px;
  }
  .av-loading-sub {
    font-size:11px;color:rgba(255,255,255,.28);letter-spacing:.3em;
    text-transform:uppercase;margin:0 0 36px;
  }
  .av-bar-wrap {width:260px;margin-bottom:28px;}
  .av-bar-track {width:100%;height:3px;background:rgba(255,255,255,.1);border-radius:3px;overflow:hidden;}
  .av-bar-fill {
    height:100%;border-radius:3px;
    background:linear-gradient(90deg,var(--green),#00d4aa);
    box-shadow:0 0 10px rgba(0,232,135,.5);
    transition:width .08s linear;
  }

  /* Header */
  .av-header {
    display:flex;align-items:center;justify-content:space-between;
    padding:9px 14px;
    background:var(--bg-secondary);
    border-bottom:1px solid var(--border);
    z-index:10;flex-shrink:0;
  }
  .av-header-left{display:flex;align-items:center;gap:10px;}
  .av-back{
    width:30px;height:30px;border-radius:7px;
    background:rgba(255,255,255,.04);border:none;
    display:flex;align-items:center;justify-content:center;
    cursor:pointer;color:rgba(255,255,255,.45);
    transition:background .12s;
  }
  .av-back:hover{background:rgba(255,255,255,.09);color:#fff}
  .av-logo{display:flex;align-items:center;gap:8px;}
  .av-logo-icon{
    width:26px;height:26px;border-radius:7px;
    background:linear-gradient(135deg,#ff4d4d,#ff8c00);
    display:flex;align-items:center;justify-content:center;font-size:13px;
  }
  .av-logo-text{
    font-family:'Exo 2',sans-serif;font-size:12px;font-weight:800;
    color:var(--text);letter-spacing:.15em;text-transform:uppercase;
  }
  .av-live-dot{
    width:5px;height:5px;border-radius:50%;
    background:var(--green);box-shadow:0 0 7px var(--green);
    animation:avPulse 1.4s infinite;
  }
  @keyframes avPulse{0%,100%{opacity:1}50%{opacity:.35}}
  .av-bal{
    display:flex;align-items:center;gap:7px;
    padding:5px 12px;border-radius:9px;
    background:var(--green-dim);border:1px solid var(--green-border);
  }
  .av-bal-label{font-size:9px;font-weight:700;color:var(--green);opacity:.65;text-transform:uppercase;letter-spacing:.04em}
  .av-bal-amt{font-family:'Exo 2',sans-serif;font-size:14px;font-weight:800;color:var(--green)}
  .av-leader-badge{
    display:inline-flex;align-items:center;gap:4px;
    padding:2px 7px;border-radius:5px;
    background:rgba(0,232,135,.12);border:1px solid rgba(0,232,135,.25);
    font-size:8px;font-weight:700;color:var(--green);text-transform:uppercase;letter-spacing:.06em;
  }

  /* History */
  .av-history{
    display:flex;align-items:center;gap:5px;
    padding:7px 14px;
    background:var(--bg-secondary);
    border-bottom:1px solid var(--border);
    overflow-x:auto;white-space:nowrap;flex-shrink:0;
    scrollbar-width:none;
  }
  .av-history::-webkit-scrollbar{display:none}
  .av-pill{
    flex-shrink:0;padding:3px 9px;border-radius:5px;
    font-size:11px;font-weight:700;border:1px solid;
  }
  .av-pill-low{color:#5bc8f5;background:rgba(91,200,245,.1);border-color:rgba(91,200,245,.2)}
  .av-pill-mid{color:#a855f7;background:rgba(168,85,247,.1);border-color:rgba(168,85,247,.2)}
  .av-pill-high{color:#ff4d4d;background:rgba(255,77,77,.1);border-color:rgba(255,77,77,.2)}

  /* Main layout */
  .av-main{display:flex;flex-direction:column;flex:1;overflow:hidden;min-height:0}
  .av-top-row{display:flex;flex:1;overflow:hidden;min-height:0}
  .av-bets-row{display:flex;overflow:hidden;flex-shrink:0}

  /* Betting history */
  .av-my-history{
    flex-shrink:0;display:flex;align-items:center;gap:0;
    padding:0;
    background:var(--bg-secondary);
    border-top:1px solid var(--border);
    overflow-x:auto;white-space:nowrap;max-height:48px;
    scrollbar-width:none;
  }
  .av-my-history::-webkit-scrollbar{display:none}
  .av-my-history-title{
    font-size:8px;font-weight:700;color:rgba(255,255,255,.25);
    text-transform:uppercase;letter-spacing:.1em;flex-shrink:0;
    padding:0 10px;display:flex;align-items:center;height:100%;
    border-right:1px solid var(--border);
  }
  .av-my-h-item{
    flex-shrink:0;display:inline-flex;align-items:center;gap:5px;
    padding:5px 10px;
    font-size:9px;font-weight:600;
    border-right:1px solid rgba(255,255,255,.03);
    transition:background .1s;
  }
  .av-my-h-item.won{color:var(--green);background:var(--green-dim)}
  .av-my-h-item.lost{color:var(--red);background:var(--red-dim)}
  .av-my-h-item.pending{color:var(--yellow);background:rgba(255,214,0,.06)}
  .av-my-h-time{font-size:7px;color:rgba(255,255,255,.25);font-weight:500}
  .av-my-h-amt{font-weight:800;font-size:10px}
  .av-my-h-mult{font-weight:800;font-size:9px}
  .av-my-h-profit{font-weight:800;font-size:9px}

  /* Bet panels */
  .av-panel{
    flex:1;display:flex;flex-direction:column;gap:7px;
    padding:8px 6px;overflow-y:auto;
    max-width:210px;
    scrollbar-width:none;
  }
  .av-panel::-webkit-scrollbar{display:none}
  .av-card{
    background:var(--bg-panel);border:1px solid var(--border);
    border-radius:11px;padding:11px;
    backdrop-filter:blur(12px);
    transition:border-color .15s;
  }
  .av-card:hover{border-color:var(--border-active)}
  .av-card.green{border-color:rgba(0,232,135,.18)}
  .av-card.red{border-color:rgba(255,77,77,.18)}
  .av-card-head{
    display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;
  }
  .av-card-label{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.1em}
  .av-card-label.g{color:var(--green)}
  .av-card-label.r{color:var(--red)}
  .av-card-won{font-size:9px;font-weight:700;color:var(--yellow)}

  .av-quick{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;margin-bottom:7px;}
  .av-qbtn{
    padding:8px 0;border-radius:6px;
    font-size:11px;font-weight:700;
    background:rgba(255,255,255,.04);color:rgba(255,255,255,.55);
    border:1px solid rgba(255,255,255,.07);cursor:pointer;
    transition:all .12s;
  }
  .av-qbtn:hover{background:rgba(255,255,255,.09);color:#fff}
  .av-qbtn.on{background:var(--green);color:#0c1220;border-color:var(--green)}

  .av-amt-row{
    display:flex;align-items:center;gap:3px;
    background:rgba(0,0,0,.28);
    border:1px solid rgba(255,255,255,.07);
    border-radius:7px;padding:5px 9px;margin-bottom:7px;
  }
  .av-amt-sym{font-size:12px;color:rgba(255,255,255,.28);font-weight:600}
  .av-amt-input{
    flex:1;background:transparent;border:none;outline:none;
    font-family:'Exo 2',sans-serif;font-size:15px;font-weight:800;
    color:var(--text);text-align:center;width:100%;
  }
  .av-amt-input:disabled{opacity:.28}
  .av-amt-inc{
    width:32px;height:32px;border-radius:6px;
    background:rgba(255,255,255,.04);border:none;
    color:rgba(255,255,255,.45);cursor:pointer;
    font-size:16px;display:flex;align-items:center;justify-content:center;
    transition:background .12s;
  }
  .av-amt-inc:hover{background:rgba(255,255,255,.09);color:#fff}

  .av-auto-row{display:flex;align-items:center;gap:5px;margin-bottom:9px;}
  .av-auto-btn{
    padding:6px 12px;border-radius:6px;border:none;cursor:pointer;
    font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;
    background:rgba(255,255,255,.04);color:rgba(255,255,255,.45);
    border:1px solid rgba(255,255,255,.09);transition:all .12s;
  }
  .av-auto-btn.on{background:var(--green);color:#0c1220;border-color:var(--green)}
  .av-auto-presets{display:flex;gap:3px;flex:1;}
  .av-auto-p{
    flex:1;padding:6px 2px;border-radius:5px;border:none;cursor:pointer;
    font-size:9px;font-weight:700;
    background:rgba(255,255,255,.04);color:rgba(255,255,255,.35);
    transition:all .12s;
  }
  .av-auto-p.on{background:var(--green);color:#0c1220}

  .av-betbtn{
    width:100%;padding:14px;border-radius:10px;
    font-family:'Exo 2',sans-serif;font-size:14px;font-weight:800;
    letter-spacing:.04em;text-transform:uppercase;border:none;cursor:pointer;
    transition:all .12s;
  }
  .av-betbtn.g{background:linear-gradient(135deg,var(--green),#00d4aa);color:#0c1220;box-shadow:0 3px 18px rgba(0,232,135,.28)}
  .av-betbtn.r{background:linear-gradient(135deg,var(--red),#ff8c00);color:#fff;box-shadow:0 3px 18px rgba(255,77,77,.28)}
  .av-betbtn.g:hover{box-shadow:0 3px 28px rgba(0,232,135,.48);transform:translateY(-1px)}
  .av-betbtn.r:hover{box-shadow:0 3px 28px rgba(255,77,77,.48);transform:translateY(-1px)}
  .av-betbtn:disabled{opacity:.3;cursor:not-allowed;transform:none!important;box-shadow:none!important}

  .av-cashbtn{
    width:100%;padding:14px;border-radius:10px;
    font-family:'Exo 2',sans-serif;font-size:14px;font-weight:800;
    background:linear-gradient(135deg,var(--yellow),#ff8c00);
    color:#0c1220;border:none;cursor:pointer;
    box-shadow:0 3px 18px rgba(255,214,0,.28);
    animation:avCashPulse .7s infinite;
  }

  .av-betbtn.av-cancelbtn-orange{
    background:linear-gradient(135deg,#f59e0b,#d97706);color:#0c1220;
    box-shadow:0 3px 18px rgba(245,158,11,.3);
  }
  .av-betbtn.av-cancelbtn-orange:hover{box-shadow:0 3px 28px rgba(245,158,11,.5);transform:translateY(-1px)}
  @keyframes avCashPulse{0%,100%{box-shadow:0 3px 18px rgba(255,214,0,.28)}50%{box-shadow:0 3px 32px rgba(255,214,0,.58)}}

  .av-result{width:100%;padding:7px;border-radius:7px;text-align:center;border:1px solid}
  .av-result.won{background:rgba(255,214,0,.1);border-color:rgba(255,214,0,.28)}
  .av-result.lost{background:rgba(255,77,77,.1);border-color:rgba(255,77,77,.28)}
  .av-result-label{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
  .av-result-label.w{color:var(--yellow)}
  .av-result-label.l{color:var(--red)}
  .av-result-amt{font-family:'Exo 2',sans-serif;font-size:14px;font-weight:900}
  .av-result-amt.w{color:var(--yellow)}
  .av-result-amt.l{color:var(--red)}

  .av-wait{width:100%;padding:7px;border-radius:7px;text-align:center;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07)}
  .av-wait-label{font-size:9px;font-weight:700;color:rgba(255,255,255,.28);text-transform:uppercase}
  .av-wait-amt{font-family:'Exo 2',sans-serif;font-size:12px;font-weight:700;color:rgba(255,255,255,.45)}

  /* Canvas area */
  .av-canvas{flex:7;position:relative;min-width:0;overflow:hidden;background:var(--bg-primary)}
  .av-canvas-bg{
    position:absolute;inset:0;width:100%;height:100%;
    object-fit:cover;opacity:0.1;z-index:0;
  }
  .av-canvas-el{position:absolute;inset:0;width:100%;height:100%;z-index:1}

  /* Mobile — game canvas 70% + live bets 30% side by side, bet panels 50/50 below */
  @media(max-width:767px){
    .av-top-row{flex-direction:row;flex:1;height:0;min-height:0;overflow:hidden}
    .av-canvas{flex:7;min-height:0;flex-shrink:0}
    .av-live{flex:none;width:30%;min-width:80px;border-top:none;border-left:1px solid var(--border);flex-direction:column;overflow:hidden}
    .av-live-head{width:100%;flex-shrink:0;border-bottom:1px solid var(--border);border-right:none;padding:4px 8px}
    .av-live-list{overflow-y:auto;overflow-x:hidden;flex:1;min-height:0}
    .av-live-item{flex-shrink:0;border-bottom:1px solid rgba(255,255,255,.03);border-right:none;padding:4px 8px;flex-direction:row;gap:4px;min-width:unset;width:100%}
    .av-live-empty{height:40px;width:unset;flex-shrink:0}
    .av-live-user{max-width:55px;font-size:9px}
    .av-live-amt{font-size:10px}
    .av-live-mult{font-size:9px}
    .av-bets-row{flex-shrink:0;overflow:hidden}
    .av-panel{flex:1;max-width:none;min-width:0;overflow-x:auto;overflow-y:hidden;padding:0}
    .av-panel::-webkit-scrollbar{display:none}
    .av-card{min-width:160px;flex-shrink:0;width:100%}
    .av-my-history{max-height:36px}
  }

  .av-overlay{
    position:absolute;inset:0;
    display:flex;align-items:center;justify-content:center;
    pointer-events:none;z-index:3;
  }
  .av-mult{
    font-family:'Exo 2',sans-serif;
    font-size:clamp(44px,7vw,74px);font-weight:900;
    letter-spacing:-.02em;text-shadow:0 0 40px currentColor;line-height:1;
  }
  .av-cd-box{
    background:rgba(0,0,0,.68);backdrop-filter:blur(14px);
    border:1px solid rgba(255,255,255,.09);border-radius:15px;
    padding:18px 36px;text-align:center;
  }
  .av-cd-num{
    font-family:'Exo 2',sans-serif;
    font-size:clamp(44px,7vw,68px);font-weight:900;
    color:var(--text);line-height:1;text-shadow:0 0 28px rgba(255,255,255,.28);
  }
  .av-cd-label{font-size:9px;font-weight:600;color:rgba(255,255,255,.38);text-transform:uppercase;letter-spacing:.2em;margin-top:5px}

  .av-crash-val{
    font-family:'Exo 2',sans-serif;font-size:clamp(24px,4vw,36px);
    font-weight:900;color:var(--red);line-height:1;
    text-shadow:0 0 20px rgba(255,77,77,.6),0 0 40px rgba(255,77,77,.3);
  }

  /* Cashout exit popups */
  .av-exit-layer{position:absolute;inset:0;pointer-events:none;z-index:4;overflow:hidden}
  .av-exit-item{
    position:absolute;pointer-events:none;
    display:flex;align-items:center;gap:5px;
    padding:4px 10px;border-radius:20px;
    background:rgba(0,232,135,.15);border:1px solid rgba(0,232,135,.3);
    animation:avExitFade 2.2s forwards;
  }
  .av-exit-avatar{
    width:16px;height:16px;border-radius:50%;
    background:var(--green-dim);border:1px solid var(--green-border);
    display:flex;align-items:center;justify-content:center;
    font-size:8px;font-weight:700;color:var(--green);
  }
  .av-exit-name{font-size:8px;font-weight:600;color:rgba(255,255,255,.5);max-width:50px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .av-exit-amt{font-size:9px;font-weight:800;color:var(--green)}
  @keyframes avExitFade{
    0%{opacity:0;transform:translateY(10px) scale(.8)}
    8%{opacity:1;transform:translateY(0) scale(1)}
    75%{opacity:1;transform:translateY(-8px)}
    100%{opacity:0;transform:translateY(-20px)}
  }

  /* Live bets */
  .av-live{
    flex:3;display:flex;flex-direction:column;
    background:var(--bg-secondary);
    border-left:1px solid var(--border);
  }
  .av-live-head{
    display:flex;align-items:center;gap:7px;
    padding:9px 11px;border-bottom:1px solid var(--border);flex-shrink:0;
  }
  .av-live-dot{width:5px;height:5px;border-radius:50%;background:#5bc8f5;animation:avPulse 1.4s infinite}
  .av-live-title{font-size:10px;font-weight:700;color:var(--text-sec);text-transform:uppercase;letter-spacing:.1em}
  .av-live-cnt{font-size:10px;font-weight:700;color:#5bc8f5}
  .av-live-list{
    flex:1;overflow-y:auto;overflow-x:hidden;
    scrollbar-width:thin;min-height:0;
    mask-image:linear-gradient(to bottom,transparent,#000 8%,#000 92%,transparent);
    -webkit-mask-image:linear-gradient(to bottom,transparent,#000 8%,#000 92%,transparent);
  }
  .av-live-item{
    display:flex;align-items:center;justify-content:space-between;
    padding:6px 11px;border-bottom:1px solid rgba(255,255,255,.03);
    border-left:3px solid transparent;
    transition:background .09s;
  }
  .av-live-item:hover{background:rgba(255,255,255,.02)}
  .av-live-item.isu{background:rgba(0,232,135,.04);border-left-color:rgba(0,232,135,.3)}
  .av-live-item.won{border-left-color:var(--green);background:rgba(0,232,135,.06)}
  .av-live-item.lost{border-left-color:var(--red);background:rgba(255,77,77,.04)}
  .av-live-item.pending{border-left-color:rgba(255,214,0,.3);background:rgba(255,214,0,.03)}
  .av-live-user{font-size:10px;font-weight:600;color:rgba(255,255,255,.45);max-width:72px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .av-live-user.isu{color:var(--green)}
  .av-live-amt{font-size:11px;font-weight:700;color:var(--text)}
  .av-live-mult{font-size:10px;font-weight:800}
  .av-live-empty{display:flex;align-items:center;justify-content:center;height:80px;font-size:10px;color:rgba(255,255,255,.13)}


`

const TICK_MS = 50
const AUTO_TICK_MS = 100
const QUICK_BET = [6, 10, 20, 50, 100, 200, 500]
const MIN_BET = 6
const MAX_BET = 1000
const AUTO_PRESETS = ['2.00', '3.00', '4.00', '5.00', '8.00', '10.00', '20.00']
const BOT_COUNT = 20
const BOT_BET_MIN = 6
const BOT_BET_MAX = 500
const BETTING_SECONDS = 8
const MIN_SMART_CRASH_SECS = 3
const MIN_REAL_BETS_FOR_SMART = 1
const DEFAULT_HE_MAX_SECS = 50

let _engineRunning = false

function LoadingScreen({ progress }) {
  return (
    <div className="av-loading">
      <div className="av-loading-icon">
        <img src="/img/aviator_jogo.png" alt="" style={{ width: 44, height: 28, objectFit: 'contain' }} />
      </div>
      <h1 className="av-loading-title">AVIATOR</h1>
      <p className="av-loading-sub">Spribe</p>
      <div className="av-bar-wrap">
        <div className="av-bar-track">
          <div className="av-bar-fill" style={{ width: `${progress}%` }} />
        </div>
      </div>
      {progress < 100 && (
        <p style={{ color: 'rgba(255,255,255,0.2)', fontSize: 10, margin: 0, letterSpacing: '.1em' }}>
          Loading assets...
        </p>
      )}
    </div>
  )
}

function BetPanel({ num, amt, setAmt, autoOn, setAutoOn, autoVal, setAutoVal, betData, phase, mult, bal, onPlace, onCash, onCancel }) {
  const hasBet = !!betData
  const isBetting = phase === 'betting'
  const isRunning = phase === 'running'
  const isCrashed = phase === 'crashed'
  const cashed = betData?.cashed
  const g = num === 1

  const won = cashed ? cashed.won : null
  const cashAmt = hasBet && !cashed ? Math.floor(betData.amount * mult * 1.5).toFixed(0) : '0'

  let actionBtn = null
  if (!hasBet) {
    const canPlace = isBetting && amt >= MIN_BET && amt <= MAX_BET && amt <= bal
    actionBtn = (
      <button className={`av-betbtn ${g ? 'g' : 'r'}`} disabled={!canPlace} onClick={onPlace}>
        {!isBetting ? 'Wait...' : amt < MIN_BET ? `Min ₨${MIN_BET}` : amt > MAX_BET ? `Max ₨${MAX_BET}` : amt > bal ? 'Low Balance' : `Bet ₨${amt}`}
      </button>
    )
  } else if (cashed) {
    actionBtn = (
      <div className="av-result won">
        <div className="av-result-label w">Cashed Out</div>
        <div className="av-result-amt w">+₨{won.toLocaleString()}</div>
      </div>
    )
  } else if (isRunning) {
    actionBtn = (
      <button className="av-cashbtn" onClick={onCash}>Cash ₨{cashAmt}</button>
    )
  } else if (isCrashed) {
    actionBtn = (
      <div className="av-result lost">
        <div className="av-result-label l">Lost</div>
        <div className="av-result-amt l">-₨{betData.amount}</div>
      </div>
    )
  } else if (isBetting) {
    actionBtn = (
      <button className="av-betbtn av-cancelbtn-orange" onClick={onCancel}>Cancel ₨{betData.amount}</button>
    )
  } else {
    actionBtn = (
      <div className="av-wait">
        <div className="av-wait-label">Bet Placed</div>
        <div className="av-wait-amt">₨{betData.amount}</div>
      </div>
    )
  }

  const inputsLocked = hasBet && (isBetting || isRunning)

  return (
    <div className={`av-card ${g ? 'green' : 'red'}`}>
      <div className="av-card-head">
        <span className={`av-card-label ${g ? 'g' : 'r'}`}>BET {num}</span>
        {won != null && <span className="av-card-won">+₨{won.toLocaleString()}</span>}
      </div>

      <div className="av-quick">
        {QUICK_BET.map(a => (
          <button key={a} className={`av-qbtn ${amt === a && !hasBet ? 'on' : ''}`}
            onClick={() => setAmt(a)} disabled={hasBet}>
            {a >= 1000 ? `${a / 1000}k` : a}
          </button>
        ))}
      </div>

      <div className="av-amt-row">
        <span className="av-amt-sym">₨</span>
        <input type="number" className="av-amt-input" value={amt}
          onChange={e => setAmt(Math.max(MIN_BET, Math.min(MAX_BET, parseInt(e.target.value) || MIN_BET)))}
          disabled={hasBet} min={MIN_BET} max={MAX_BET} />
        <button className="av-amt-inc" onClick={() => setAmt(Math.min(MAX_BET, Math.min(bal, amt + 100)))} disabled={hasBet}>+</button>
      </div>

      <div className="av-auto-row">
        <button className={`av-auto-btn ${autoOn ? 'on' : ''}`}
          onClick={() => setAutoOn(o => !o)} disabled={inputsLocked}>Auto</button>
        {autoOn && (
          <div className="av-auto-presets">
            {AUTO_PRESETS.map(p => (
              <button key={p} className={`av-auto-p ${autoVal === p ? 'on' : ''}`}
                onClick={() => setAutoVal(p)} disabled={inputsLocked}>{p}x</button>
            ))}
          </div>
        )}
      </div>

      {actionBtn}
    </div>
  )
}

function multColor(m) {
  if (m >= 10) return 'var(--red)'
  if (m >= 5) return 'var(--yellow)'
  if (m >= 2) return 'var(--green)'
  return '#fff'
}
function histClass(v) {
  const n = typeof v === 'number' ? v : parseFloat(v)
  if (n >= 10) return 'av-pill-high'
  if (n >= 2) return 'av-pill-mid'
  return 'av-pill-low'
}

export default function AviatorGame() {
  const navigate = useNavigate()
  const { user, isLoggedIn, updateBalance } = useAuth()
  const toast = useToast()

  const [showLoading, setShowLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [phase, setPhase] = useState('betting')
  const [mult, setMult] = useState(1.00)
  const [cd, setCd] = useState(BETTING_SECONDS)
  const [crashedAt, setCrashedAt] = useState(null)
  const [bal, setBal] = useState(0)
  const [live, setLive] = useState([])
  const [hist, setHist] = useState(() => {
    try { return JSON.parse(localStorage.getItem('aviator_crash_history') || '[]') } catch { return [] }
  })

  const [myHistory, setMyHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem('aviator_my_bets') || '[]') } catch { return [] }
  })
  const [cashoutExits, setCashoutExits] = useState([])
  const [isLeader, setIsLeader] = useState(false)
  const exitCountRef = useRef(0)
  const userBetsRef = useRef([])

  const [b1a, setB1a] = useState(10)
  const [b1o, setB1o] = useState(false)
  const [b1v, setB1v] = useState('2.00')
  const [b1d, setB1d] = useState(null)
  const [b2a, setB2a] = useState(10)
  const [b2o, setB2o] = useState(false)
  const [b2v, setB2v] = useState('2.00')
  const [b2d, setB2d] = useState(null)

  const multRef = useRef(1.00)
  const phaseRef = useRef('betting')
  const autoTickRef = useRef(null)
  const canvasRef = useRef(null)
  const planeRef = useRef({ x: 0, y: 0, trail: [], fr: 0 })
  const roundRealBetsRef = useRef(0)
  const roundExitedAmtRef = useRef(0)
  const roundExitedCountRef = useRef(0)

  const leaderRef = useRef(false)
  const roundIdRef = useRef(null)
  const crashPtRef = useRef(0)
  const loopRef = useRef(null)
  const flightStartRef = useRef(0)
  const betTimeoutsRef = useRef([])
  const channelsRef = useRef([])
  const liveBetsRef = useRef(JSON.parse(localStorage.getItem('aviator_live_bets') || '[]'))
  const histRef = useRef(JSON.parse(localStorage.getItem('aviator_crash_history') || '[]'))
  const cdRef = useRef(null)
  const crashTimerRef = useRef(null)
  const myIdRef = useRef(`c_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`)

  useEffect(() => {
    if (user?.balance !== undefined) setBal(user.balance)
  }, [user])
  useEffect(() => {
    if (!isLoggedIn) navigate('/login')
  }, [isLoggedIn, navigate])
  useEffect(() => { multRef.current = mult }, [mult])
  useEffect(() => { phaseRef.current = phase }, [phase])

  const addCashoutExit = useCallback((name, profit) => {
    exitCountRef.current++
    const id = `ex_${exitCountRef.current}_${Date.now()}`
    const left = 20 + Math.random() * 50
    const top = 50 + Math.random() * 40
    setCashoutExits(prev => [...prev, { id, name, profit, left, top }])
    setTimeout(() => {
      setCashoutExits(prev => prev.filter(e => e.id !== id))
    }, 2500)
  }, [])

  const pushMyHistory = useCallback((entry) => {
    setMyHistory(h => {
      const updated = [{ ...entry, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }, ...h].slice(0, 15)
      try { localStorage.setItem('aviator_my_bets', JSON.stringify(updated)) } catch {}
      return updated
    })
  }, [])

  const prevLiveRef = useRef([])
  useEffect(() => {
    if (prevLiveRef.current.length > 0) {
      const prevMap = new Map(prevLiveRef.current.map(b => [b.id, b]))
      live.forEach(b => {
        const prev = prevMap.get(b.id)
        if (prev && prev.status === 'pending' && b.status === 'won' && b.username !== user?.username) {
          const won = Number(b.cashout_amount || b.won_amount || 0)
          addCashoutExit(b.username, won)
        }
      })
    }
    prevLiveRef.current = [...live]
  }, [live, addCashoutExit, user])

  const prevPhaseRef = useRef('betting')
  useEffect(() => {
    const prev = prevPhaseRef.current
    const curr = phase
    prevPhaseRef.current = curr

    if (curr === 'crashed' && prev !== 'crashed') {
      setMyHistory(h => {
        const updated = h.map(entry => {
          if (entry.pending) {
            return { ...entry, won: false, pending: false, mult: null, profit: 0 }
          }
          return entry
        })
        try { localStorage.setItem('aviator_my_bets', JSON.stringify(updated)) } catch {}
        return updated
      })
    }

    if (curr === 'betting' && prev === 'crashed') {
      setB1d(null)
      setB2d(null)
    }
  }, [phase, user])

  const loadingTick = useRef(null)
  useEffect(() => {
    let prog = 0
    loadingTick.current = setInterval(() => {
      prog += Math.random() * 18 + 8
      if (prog >= 100) {
        prog = 100
        clearInterval(loadingTick.current)
        setLoadingProgress(100)
        setTimeout(() => setShowLoading(false), 300)
      } else {
        setLoadingProgress(prog)
      }
    }, 150)
    return () => clearInterval(loadingTick.current)
  }, [])

  const broadcast = useCallback(async (state) => {
    try {
      localStorage.setItem('aviator_game_state', JSON.stringify({ ...state, roundId: roundIdRef.current, timestamp: Date.now() }))
    } catch (e) { /* ignore */ }
  }, [])

  const broadcastCrash = useCallback(async (roundId, crashPt) => {
    try {
      localStorage.setItem('aviator_game_crash', JSON.stringify({ roundId, crashPoint: crashPt, timestamp: Date.now() }))
    } catch (e) { /* ignore */ }
  }, [])

  const placeBotBet = useCallback((roundId) => {
    const amt = generateBotBetAmount(BOT_BET_MIN, BOT_BET_MAX)
    const auto = generateBotAutoCashout()
    const name = getRandomBotName()
    const bet = {
      id: `bot_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      round_id: roundId,
      user_id: null,
      username: name,
      amount: amt,
      auto_cashout_at: auto,
      cashout_at: null,
      cashout_amount: null,
      is_bot: true,
      status: 'pending',
      won_amount: 0,
    }
    liveBetsRef.current = [...liveBetsRef.current, bet]
    setLive([...liveBetsRef.current])
    return bet
  }, [])

  const processAutoCashouts = useCallback((currentMult) => {
    let changed = false
    liveBetsRef.current = liveBetsRef.current.map(b => {
      if (b.status !== 'pending' || !b.auto_cashout_at) return b
      if (currentMult >= b.auto_cashout_at) {
        changed = true
        const updated = { ...b, status: 'won', cashout_at: b.auto_cashout_at, cashout_amount: Math.floor(b.amount * b.auto_cashout_at), won_amount: Math.floor(b.amount * b.auto_cashout_at) }
        if (!b.is_bot) {
          roundExitedAmtRef.current += b.amount * b.auto_cashout_at
          roundExitedCountRef.current++
        }
        return updated
      }
      return b
    })
    if (changed) setLive([...liveBetsRef.current])
  }, [])

  // Game engine — starts when loading is done, runs continuously
  useEffect(() => {
    if (showLoading) return
    if (_engineRunning) return
    _engineRunning = true

    const crashTimer = { id: null }
    const cdIv = { id: null }
    const loopIv = { id: null }

    const saveState = (state) => {
      try { localStorage.setItem('aviator_game_state', JSON.stringify({ ...state, timestamp: Date.now() })) } catch {}
      broadcastGameState(state)
    }

    const runCrash = (actualCrashedAt) => {
      clearInterval(loopIv.id)
      phaseRef.current = 'crashed'
      setPhase('crashed')
      setCrashedAt(actualCrashedAt)
      saveState({ phase: 'crashed', crashPoint: actualCrashedAt })

      histRef.current = [actualCrashedAt, ...histRef.current.slice(0, 19)]
      try { localStorage.setItem('aviator_crash_history', JSON.stringify(histRef.current)) } catch {}
      setHist([...histRef.current])
      liveBetsRef.current = liveBetsRef.current.map(b =>
        b.status === 'pending' ? { ...b, status: 'lost' } : b
      )
      setLive([...liveBetsRef.current])
      try { localStorage.setItem('aviator_live_bets', JSON.stringify(liveBetsRef.current)) } catch {}

      const realBetTotal = roundRealBetsRef.current
      const realExitTotal = roundExitedAmtRef.current
      if (realBetTotal > 0) {
        updateHouseEdgePool(realBetTotal, realExitTotal, actualCrashedAt)
      }

      try { localStorage.removeItem('aviator_user_bet_1') } catch {}
      try { localStorage.removeItem('aviator_user_bet_2') } catch {}

      crashTimer.id = setTimeout(() => {
        betTimeoutsRef.current.forEach(clearTimeout)
        betTimeoutsRef.current = []
        runGame()
      }, 3000)
    }

    const runFlight = (crashPt, startTime) => {
      phaseRef.current = 'running'
      flightStartRef.current = startTime
      setPhase('running')

      const settings = getGameSettingsLocal()
      const heMode = settings?.heMode || 'off'
      const heTargetPct = settings?.heTargetPct ?? 5
      const heMinSecs = settings?.heMinSecs ?? 3
      const heMaxSecs = settings?.heMaxSecs ?? DEFAULT_HE_MAX_SECS
      const autoTargetSecs = settings?.autoTargetSecs ?? 8
      let autoCrashed = false
      let smartTriggered = false

      loopIv.id = setInterval(() => {
        const elapsed = (Date.now() - flightStartRef.current) / 1000
        const m = Math.min(100, parseFloat(Math.pow(Math.E, 0.06 * elapsed).toFixed(2)))
        const mFixed = parseFloat(m.toFixed(2))
        multRef.current = mFixed
        setMult(mFixed)
        saveState({ phase: 'running', mult: mFixed, crashPoint: crashPt, startTime: flightStartRef.current })

        try { localStorage.setItem('aviator_live_bets', JSON.stringify(liveBetsRef.current)) } catch {}

        // Admin manual crash — crash at current actual mult instantly
        const manualCrashSignal = getManualCrash()
        if (manualCrashSignal) {
          clearManualCrash()
          clearInterval(loopIv.id)
          broadcastLiveHE({ event: 'crash', mode: 'manual', mult: mFixed, elapsed })
          broadcastLiveHEMetrics({ event: 'crash', mode: 'manual', mult: mFixed, elapsed })
          runCrash(mFixed)
          return
        }
        
        // Check Supabase crash signal in background (non-blocking)
        checkManualCrash().then(hasSignal => {
          if (hasSignal) {
            clearManualCrash()
            clearInterval(loopIv.id)
            broadcastLiveHE({ event: 'crash', mode: 'manual', mult: mFixed, elapsed })
            broadcastLiveHEMetrics({ event: 'crash', mode: 'manual', mult: mFixed, elapsed })
            runCrash(mFixed)
          }
        })

        // Smart auto house edge — crash when target edge % is reached
        let targetMult = null
        let liveEdge = 0
        let pendingAmt = 0
        let exitRate = 0

        if (heMode === 'smart' && !smartTriggered && elapsed >= heMinSecs) {
          const realBets = roundRealBetsRef.current
          const exitedAmt = roundExitedAmtRef.current
          const exitedCount = roundExitedCountRef.current

          if (realBets >= MIN_REAL_BETS_FOR_SMART && exitedCount > 0) {
            pendingAmt = realBets - exitedAmt
            const safeExitAmt = pendingAmt * (1 - heTargetPct / 100)
            const exitTarget = realBets - safeExitAmt
            targetMult = exitTarget / realBets
            liveEdge = (pendingAmt / realBets) * 100
            exitRate = (exitedCount / realBets) * 100

            if (mFixed >= targetMult) {
              smartTriggered = true
              clearInterval(loopIv.id)
              broadcastLiveHE({ event: 'crash', mode: 'smart', mult: mFixed, targetMult, elapsed, liveEdge, pendingAmt, exitedAmt, exitRate })
              broadcastLiveHEMetrics({ event: 'crash', mode: 'smart', mult: mFixed, targetMult, elapsed, liveEdge, pendingAmt, exitedAmt, exitRate, realBets: roundRealBetsRef.current, exitedAmt: roundExitedAmtRef.current })
              runCrash(mFixed)
              return
            }
          }

          // Max time cap for smart mode
          if (elapsed >= heMaxSecs) {
            smartTriggered = true
            clearInterval(loopIv.id)
            broadcastLiveHE({ event: 'crash', mode: 'smart_max', mult: mFixed, elapsed })
            broadcastLiveHEMetrics({ event: 'crash', mode: 'smart_max', mult: mFixed, elapsed })
            runCrash(mFixed)
            return
          }
        }

        // Time-based auto crash
        if (heMode === 'time' && !autoCrashed && elapsed >= autoTargetSecs) {
          autoCrashed = true
          clearInterval(loopIv.id)
          broadcastLiveHE({ event: 'crash', mode: 'time', mult: mFixed, elapsed })
          broadcastLiveHEMetrics({ event: 'crash', mode: 'time', mult: mFixed, elapsed })
          runCrash(mFixed)
          return
        }

        // Natural crash
        if (mFixed >= crashPt) {
          const exitedAmt = roundExitedAmtRef.current
          const realBets = roundRealBetsRef.current
          pendingAmt = realBets - exitedAmt
          liveEdge = realBets > 0 ? (pendingAmt / realBets) * 100 : 0
          exitRate = roundExitedCountRef.current
          broadcastLiveHE({ event: 'crash', mode: 'natural', mult: mFixed, elapsed, liveEdge, pendingAmt, exitedAmt, exitRate })
          broadcastLiveHEMetrics({ event: 'crash', mode: 'natural', mult: mFixed, elapsed, liveEdge, pendingAmt, exitedAmt, exitRate, realBets, exitedAmt })
          clearInterval(loopIv.id)
          runCrash(mFixed)
        }

        // Broadcast live metrics every tick for admin panel
        if (heMode === 'smart') {
          const realBets = roundRealBetsRef.current
          const exitedAmt = roundExitedAmtRef.current
          const exitedCount = roundExitedCountRef.current
          const pm = realBets - exitedAmt
          const edge = realBets > 0 ? (pm / realBets) * 100 : 0
          const rate = realBets > 0 ? (exitedCount / realBets) * 100 : 0
          const tmult = realBets >= MIN_REAL_BETS_FOR_SMART && exitedCount > 0
            ? (realBets - pm * (1 - heTargetPct / 100)) / realBets
            : null

          broadcastLiveHE({
            event: 'live',
            realBets,
            exitedAmt,
            pendingAmt: pm,
            liveEdge: edge,
            exitRate: rate,
            targetMult: tmult,
            heTargetPct,
            heMode,
            mFixed,
            elapsed,
          })
          
          broadcastLiveHEMetrics({
            event: 'live',
            realBets,
            exitedAmt,
            pendingAmt: pm,
            liveEdge: edge,
            exitRate: rate,
            targetMult: tmult,
            elapsed: Math.floor(elapsed),
          })
        }
      }, TICK_MS)
    }

    const runBetting = (crashPt, countdownStart) => {
      phaseRef.current = 'betting'
      multRef.current = 1.00
      setPhase('betting')
      setMult(1.00)
      setCrashedAt(null)
      setB1d(null)
      setB2d(null)
      roundRealBetsRef.current = 0
      roundExitedAmtRef.current = 0
      roundExitedCountRef.current = 0

      // Restore previous round's live bets if they exist (for display after refresh)
      // Don't clear them — let them show until crash updates them

      const elapsed = (Date.now() - countdownStart) / 1000
      let tick = Math.max(0, Math.ceil(BETTING_SECONDS - elapsed))
      setCd(tick)
      saveState({ phase: 'betting', crashPoint: crashPt, countdownStart, countdown: tick })

      for (let i = 0; i < BOT_COUNT; i++) {
        const delay = Math.random() * BETTING_SECONDS * 700
        const amt = generateBotBetAmount(BOT_BET_MIN, BOT_BET_MAX)
        const auto = generateBotAutoCashout()
        const name = getRandomBotName()
        const t = setTimeout(() => {
          if (phaseRef.current === 'betting') {
            liveBetsRef.current = [...liveBetsRef.current, {
              id: `bot_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
              round_id: roundIdRef.current, user_id: null, username: name,
              amount: amt, auto_cashout_at: auto,
              cashout_at: null, cashout_amount: null,
              is_bot: true, status: 'pending', won_amount: 0,
            }]
            setLive([...liveBetsRef.current])
            try { localStorage.setItem('aviator_live_bets', JSON.stringify(liveBetsRef.current)) } catch {}
          }
        }, delay)
        betTimeoutsRef.current.push(t)
      }

      if (tick <= 0) {
        runFlight(crashPt, Date.now())
        return
      }

      cdIv.id = setInterval(() => {
        tick--
        setCd(tick)
        saveState({ phase: 'betting', crashPoint: crashPt, countdownStart, countdown: tick })
        if (tick <= 0) {
          clearInterval(cdIv.id)
          runFlight(crashPt, Date.now())
        }
      }, 1000)
    }

    const runGame = () => {
      const settings = getGameSettingsLocal()
      const houseEdge = settings?.houseEdge != null ? settings.houseEdge : 0.05
      const crashPt = parseFloat(generateCrashPoint(houseEdge).toFixed(2))
      crashPtRef.current = crashPt
      roundIdRef.current = `r_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`
      runBetting(crashPt, Date.now())
    }

    // On load, check for existing game state and resume
    const startTimer = setTimeout(() => {
      // Load saved live bets
      try {
        const savedBets = localStorage.getItem('aviator_live_bets')
        if (savedBets) {
          liveBetsRef.current = JSON.parse(savedBets)
          setLive([...liveBetsRef.current])
        }
      } catch {}

      // Load saved user bets
      try {
        const savedB1 = localStorage.getItem('aviator_user_bet_1')
        if (savedB1) {
          const b1 = JSON.parse(savedB1)
          if (b1 && !b1.cashed) {
            setB1d(b1)
            if (b1.autoVal) {
              setB1o(true)
              setB1v(b1.autoVal)
            }
          }
        }
      } catch {}
      try {
        const savedB2 = localStorage.getItem('aviator_user_bet_2')
        if (savedB2) {
          const b2 = JSON.parse(savedB2)
          if (b2 && !b2.cashed) {
            setB2d(b2)
            if (b2.autoVal) {
              setB2o(true)
              setB2v(b2.autoVal)
            }
          }
        }
      } catch {}

      try {
        const saved = localStorage.getItem('aviator_game_state')
        if (saved) {
          const s = JSON.parse(saved)
          const age = Date.now() - (s.timestamp || 0)

          if (s.phase === 'running' && s.crashPoint && s.startTime && age < 30000) {
            // Resume running game
            const elapsed = (Date.now() - s.startTime) / 1000
            const m = Math.min(100, parseFloat(Math.pow(Math.E, 0.06 * elapsed).toFixed(2)))
            const mFixed = parseFloat(m.toFixed(2))
            if (mFixed >= s.crashPoint) {
              // Already crashed — show crash value
              crashPtRef.current = s.crashPoint
              histRef.current = [s.crashPoint, ...histRef.current.slice(0, 19)]
              try { localStorage.setItem('aviator_crash_history', JSON.stringify(histRef.current)) } catch {}
              setHist([...histRef.current])
              setMult(s.crashPoint)
              setCrashedAt(s.crashPoint)
              phaseRef.current = 'crashed'
              setPhase('crashed')
              crashTimer.id = setTimeout(runGame, 3000)
            } else {
              crashPtRef.current = s.crashPoint
              setMult(mFixed)
              runFlight(s.crashPoint, s.startTime)
            }
          } else if (s.phase === 'crashed' && s.crashPoint && age < 15000) {
            // Show crash value and restart soon
            crashPtRef.current = s.crashPoint
            histRef.current = [s.crashPoint, ...histRef.current.slice(0, 19)]
            try { localStorage.setItem('aviator_crash_history', JSON.stringify(histRef.current)) } catch {}
            setHist([...histRef.current])
            setMult(s.crashPoint)
            setCrashedAt(s.crashPoint)
            phaseRef.current = 'crashed'
            setPhase('crashed')
            crashTimer.id = setTimeout(runGame, 3000)
          } else if (s.phase === 'betting' && s.crashPoint && s.countdownStart && age < 30000) {
            // Resume betting countdown
            crashPtRef.current = s.crashPoint
            runBetting(s.crashPoint, s.countdownStart)
          } else {
            // State too old or crashed — start new round
            runGame()
          }
        } else {
          runGame()
        }
      } catch { runGame() }
    }, 200)

    return () => {
      clearTimeout(startTimer)
      clearTimeout(crashTimer.id)
      clearInterval(cdIv.id)
      clearInterval(loopIv.id)
      betTimeoutsRef.current.forEach(clearTimeout)
      betTimeoutsRef.current = []
    }
  }, [showLoading])

  const cashoutInternal = useCallback(async (betData, multiplier, setter, betNum) => {
    if (!betData || betData.cashed) return
    const won = Math.floor(betData.amount * multiplier * 1.5)
    const newBal = bal + won
    setBal(newBal)
    setter({ ...betData, cashed: { won } })
    updateBalance(newBal)
    try { localStorage.removeItem(betNum === 1 ? 'aviator_user_bet_1' : 'aviator_user_bet_2') } catch {}
    roundExitedAmtRef.current += betData.amount * multiplier
    roundExitedCountRef.current++
    setMyHistory(h => {
      const updated = h.map(entry => {
        if (entry.pending && entry.betId === betData.id) {
          return { amount: betData.amount, mult: multiplier * 1.5, won: true, profit: won, pending: false }
        }
        return entry
      })
      try { localStorage.setItem('aviator_my_bets', JSON.stringify(updated)) } catch {}
      return updated
    })
    addCashoutExit(user?.username || 'You', won)
    if (betData.dbBetId) apiCashoutBet(betData.dbBetId, multiplier).catch(() => {})
    toast.success(`Cashed ${(multiplier * 1.5).toFixed(2)}x — +₨${won.toLocaleString()}`)
  }, [bal, updateBalance, toast, addCashoutExit, user])

  const checkAutoCashout = useCallback((currentMult) => {
    const check = (betData, setter, betNum) => {
      if (!betData || betData.cashed) return
      const autoVal = betData.autoVal
      if (!autoVal) return
      const displayTarget = parseFloat(autoVal)
      const actualTarget = displayTarget / 1.5
      if (currentMult >= actualTarget) {
        cashoutInternal(betData, actualTarget, setter, betNum)
      }
    }
    check(b1d, setB1d, 1)
    check(b2d, setB2d, 2)
  }, [b1d, b2d, cashoutInternal])

  useEffect(() => {
    if (phase === 'running') {
      autoTickRef.current = setInterval(() => checkAutoCashout(multRef.current), AUTO_TICK_MS)
    } else {
      clearInterval(autoTickRef.current)
    }
    return () => clearInterval(autoTickRef.current)
  }, [phase, checkAutoCashout])

  const place = useCallback((num) => {
    if (!isLoggedIn) { toast.error('Login to bet'); return }
    const a = num === 1 ? b1a : b2a
    if (a < MIN_BET) { toast.error(`Min ₨${MIN_BET}`); return }
    if (a > MAX_BET) { toast.error(`Max ₨${MAX_BET}`); return }
    if (a > bal) { toast.error('Low balance'); return }
    const autoVal = (num === 1 ? b1o : b2o) ? (num === 1 ? b1v : b2v) : null
    const betId = `u_${Date.now()}`

    setBal(bal - a)
    updateBalance(bal - a)

    const entry = { id: betId, amount: a, autoVal, cashed: null, dbBetId: null }
    if (num === 1) { setB1d(entry); try { localStorage.setItem('aviator_user_bet_1', JSON.stringify(entry)) } catch {} }
    else { setB2d(entry); try { localStorage.setItem('aviator_user_bet_2', JSON.stringify(entry)) } catch {} }

    const liveBet = {
      id: betId, round_id: roundIdRef.current || null,
      user_id: user?.id || null, username: user?.username || 'You',
      amount: a, auto_cashout_at: autoVal ? parseFloat(autoVal) : null,
      cashout_at: null, cashout_amount: null,
      is_bot: false, status: 'pending', won_amount: 0,
    }
    liveBetsRef.current = [...liveBetsRef.current, liveBet]
    setLive([...liveBetsRef.current])
    roundRealBetsRef.current += a

    pushMyHistory({ amount: a, mult: null, won: false, profit: 0, pending: true, betId, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) })

    toast.success(`Bet ${num}: ₨${a} placed`)
  }, [isLoggedIn, b1a, b1o, b1v, b2a, b2o, b2v, bal, user, updateBalance, toast, pushMyHistory])

  const cashout = useCallback((num) => {
    if (phaseRef.current !== 'running') return
    const betData = num === 1 ? b1d : b2d
    const setter = num === 1 ? setB1d : setB2d
    cashoutInternal(betData, multRef.current, setter, num)
  }, [b1d, b2d, cashoutInternal])

  const cancelBet = useCallback((num) => {
    const betData = num === 1 ? b1d : b2d
    if (!betData) return
    const newBal = bal + betData.amount
    setBal(newBal)
    updateBalance(newBal)
    if (num === 1) { setB1d(null); try { localStorage.removeItem('aviator_user_bet_1') } catch {} }
    else { setB2d(null); try { localStorage.removeItem('aviator_user_bet_2') } catch {} }
    liveBetsRef.current = liveBetsRef.current.filter(b => b.id !== betData.id)
    setLive([...liveBetsRef.current])
    setMyHistory(h => {
      const updated = h.filter(entry => entry.betId !== betData.id)
      try { localStorage.setItem('aviator_my_bets', JSON.stringify(updated)) } catch {}
      return updated
    })
    toast.success('Bet cancelled')
  }, [b1d, b2d, bal, updateBalance, toast])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')

    let bgCanvas = null
    let planeImgLoaded = false
    const img = new Image()
    img.src = '/img/aviator_jogo.png'
    img.onload = () => { planeImgLoaded = true }
    img.onerror = () => { planeImgLoaded = false }

    let W = 0
    let H = 0
    let planeX = 0
    let planeY = 0
    let frameCount = 0

    const buildBg = (w, h) => {
      const offCtx = document.createElement('canvas').getContext('2d')
      offCtx.canvas.width = w
      offCtx.canvas.height = h
      const bc = offCtx.createLinearGradient(0, 0, 0, h)
      bc.addColorStop(0, '#0c1220')
      bc.addColorStop(1, '#060e1a')
      offCtx.fillStyle = bc
      offCtx.fillRect(0, 0, w, h)
      offCtx.strokeStyle = 'rgba(255,255,255,0.022)'
      offCtx.lineWidth = 1
      for (let i = 0; i < w; i += 28) { offCtx.beginPath(); offCtx.moveTo(i, 0); offCtx.lineTo(i, h); offCtx.stroke() }
      for (let i = 0; i < h; i += 28) { offCtx.beginPath(); offCtx.moveTo(0, i); offCtx.lineTo(w, i); offCtx.stroke() }
      offCtx.fillStyle = 'rgba(255,255,255,0.12)'
      offCtx.font = 'bold 10px monospace'
      for (let i = 1; i <= 10; i++) {
        const y = h - (i / 10) * h * 0.84 - h * 0.07
        offCtx.fillText(`${i}x`, 3, y + 3)
        offCtx.strokeStyle = 'rgba(0,232,135,0.06)'
        offCtx.beginPath(); offCtx.moveTo(20, y); offCtx.lineTo(w, y); offCtx.stroke()
      }
      return offCtx.canvas
    }

    const resize = () => {
      W = canvas.offsetWidth
      H = canvas.offsetHeight
      canvas.width = W
      canvas.height = H
      bgCanvas = buildBg(W, H)
    }
    resize()
    window.addEventListener('resize', resize)

    const draw = () => {
      frameCount++
      const currentPhase = phaseRef.current
      const currentMult = multRef.current

      if (!bgCanvas || W === 0 || H === 0) {
        raf = requestAnimationFrame(draw)
        return
      }

      ctx.clearRect(0, 0, W, H)
      ctx.drawImage(bgCanvas, 0, 0)

      if (currentPhase === 'running' && currentMult > 1) {
        const originX = 5
        const originY = H * 0.90
        const maxTravelX = Math.max(W - 220, W * 0.65)
        const maxTravelY = H * 0.78
        const progress = Math.min(1, Math.log(currentMult) / Math.log(50))
        const eased = Math.pow(progress, 0.6)
        const nx = originX + eased * maxTravelX
        const ny = originY - eased * maxTravelY
        const endX = nx - 15
        const endY = ny + 5
        const cpx = (originX + endX) * 0.5
        const cpy = originY - (originY - endY) * 0.08

        ctx.strokeStyle = 'rgba(0,255,157,0.18)'
        ctx.lineWidth = 10
        ctx.lineCap = 'round'
        ctx.beginPath()
        ctx.moveTo(originX, originY)
        ctx.quadraticCurveTo(cpx, cpy, endX, endY)
        ctx.stroke()

        ctx.strokeStyle = '#00ff9d'
        ctx.lineWidth = 3
        ctx.beginPath()
        ctx.moveTo(originX, originY)
        ctx.quadraticCurveTo(cpx, cpy, endX, endY)
        ctx.stroke()

        planeX = nx
        planeY = ny

        if (planeImgLoaded) ctx.drawImage(img, nx - 50, ny - 32, 100, 64)

        const displayMult = currentMult * 1.5
        ctx.fillStyle = displayMult >= 10 ? '#ff4d4d' : displayMult >= 5 ? '#ffd600' : '#00e887'
        ctx.font = 'bold 24px sans-serif'
        ctx.fillText(`${displayMult.toFixed(2)}x`, nx + 10, ny + 8)
      }

      if (currentPhase === 'crashed' && planeX > 0) {
        for (let i = 0; i < 15; i++) {
          const ag = (i / 15) * Math.PI * 2
          const di = 14 + Math.sin(frameCount * 0.4 + i) * 12
          ctx.fillStyle = ['#dc2626', '#f97316', '#fde047'][i % 3]
          ctx.globalAlpha = 0.35 + Math.sin(frameCount * 0.4 + i) * 0.2
          ctx.beginPath()
          ctx.arc(planeX + Math.cos(ag) * di, planeY + Math.sin(ag) * di, 2, 0, Math.PI * 2)
          ctx.fill()
        }
        ctx.globalAlpha = 1
      }

      if (currentPhase !== 'running') {
        if (planeX !== 0) { planeX = 0; planeY = 0; frameCount = 0 }
        bgCanvas = buildBg(W, H)
      }

      raf = requestAnimationFrame(draw)
    }

    let raf = requestAnimationFrame(draw)
    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(raf)
    }
  }, [showLoading])

  return (
    <>
      <style>{CSS}</style>
      <div className="av-root" style={{ width: '100%', height: '100dvh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {showLoading && <LoadingScreen progress={loadingProgress} />}

        {!showLoading && (
          <>
            <div className="av-header">
              <div className="av-header-left">
                <button className="av-back" onClick={() => navigate(-1)}>
                  <ChevronLeft size={15} />
                </button>
                <div className="av-logo">
                  <div className="av-logo-icon">✈</div>
                  <span className="av-logo-text">Aviator</span>
                  <div className="av-live-dot" />
                </div>
                {isLeader && <span className="av-leader-badge">Hosting</span>}
              </div>
              <div className="av-bal">
                <span className="av-bal-label">Balance</span>
                <span className="av-bal-amt">₨{bal.toLocaleString()}</span>
              </div>
            </div>

            <div className="av-history">
              {hist.length === 0 && (
                <span style={{ fontSize: 10, color: 'rgba(255,255,255,0.18)', paddingRight: 6 }}>Waiting...</span>
              )}
              {hist.map((h, i) => (
                <div key={`${h}-${i}`} className={`av-pill ${histClass(h)}`}>
                  {typeof h === 'number' ? (h * 1.5).toFixed(2) : h}x
                </div>
              ))}
            </div>

            <div className="av-main">
              {/* Top row: Game canvas (70%) + Live bets (30%) */}
              <div className="av-top-row">
                <div className="av-canvas">
                  <img src="/img/aviator_background.jpeg" alt="" className="av-canvas-bg" />
                  <canvas ref={canvasRef} className="av-canvas-el" />

                  {/* Cashout exit popups */}
                  <div className="av-exit-layer">
                    {cashoutExits.map(e => (
                      <div key={e.id} className="av-exit-item" style={{ left: `${e.left}%`, top: `${e.top}%` }}>
                        <div className="av-exit-avatar">{(e.name || '?')[0].toUpperCase()}</div>
                        <span className="av-exit-name">{e.name}</span>
                        <span className="av-exit-amt">+₨{e.profit.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>

                  <div className="av-overlay">
                    {phase === 'betting' && (
                      <div className="av-cd-box">
                        <div className="av-cd-num">{cd}</div>
                        <div className="av-cd-label">Place your bets</div>
                      </div>
                    )}
                    {phase === 'crashed' && crashedAt && (
                      <div className="av-crash-val">{(crashedAt * 1.5).toFixed(2)}x</div>
                    )}
                  </div>
                </div>

                {/* Live bets panel */}
                <div className="av-live">
                  <div className="av-live-head">
                    <div className="av-live-dot" />
                    <span className="av-live-title">Live</span>
                    <span className="av-live-cnt">{live.length}</span>
                  </div>
                  <div className="av-live-list">
                    {live.length === 0 ? (
                      <div className="av-live-empty">Waiting for bets...</div>
                    ) : live.map(b => (
                      <div key={b.id} className={`av-live-item ${!b.is_bot ? 'isu' : ''} ${b.status === 'won' ? 'won' : b.status === 'lost' ? 'lost' : b.status === 'pending' ? 'pending' : ''}`}>
                        <span className={`av-live-user ${!b.is_bot ? 'isu' : ''}`}>{b.username}</span>
                        <span className="av-live-amt">₨{Number(b.amount || 0).toLocaleString()}</span>
                        <span className="av-live-mult" style={{ color: b.status === 'won' ? 'var(--yellow)' : b.auto_cashout_at ? 'rgba(255,214,0,.45)' : 'rgba(255,255,255,.2)' }}>
                        {b.status === 'won' ? `${(Number(b.cashout_at || 0) * 1.5).toFixed(2)}x`
                          : b.auto_cashout_at ? `A:${Number(b.auto_cashout_at).toFixed(1)}`
                            : '—'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom row: Bet 1 (50%) + Bet 2 (50%) */}
              <div className="av-bets-row">
                <div className="av-panel">
                  <BetPanel
                    num={1} amt={b1a} setAmt={setB1a}
                    autoOn={b1o} setAutoOn={setB1o}
                    autoVal={b1v} setAutoVal={setB1v}
                    betData={b1d} phase={phase} mult={mult}
                    bal={bal} onPlace={() => place(1)} onCash={() => cashout(1)} onCancel={() => cancelBet(1)} />
                </div>

                <div className="av-panel">
                  <BetPanel
                    num={2} amt={b2a} setAmt={setB2a}
                    autoOn={b2o} setAutoOn={setB2o}
                    autoVal={b2v} setAutoVal={setB2v}
                    betData={b2d} phase={phase} mult={mult}
                    bal={bal} onPlace={() => place(2)} onCash={() => cashout(2)} onCancel={() => cancelBet(2)} />
                </div>
              </div>

              {/* My Betting History */}
              <div className="av-my-history">
                <span className="av-my-history-title">My Bets</span>
                {myHistory.length === 0 ? (
                  <span style={{ fontSize: 9, color: 'rgba(255,255,255,0.15)', padding: '0 10px', flexShrink: 0, height: '100%', display: 'flex', alignItems: 'center' }}>Place a bet to start</span>
                ) : myHistory.map((h, i) => (
                  <div key={`${h.amount}-${h.pending ? 'p' : 'r'}-${i}-${h.time || ''}`} className={`av-my-h-item ${h.pending ? 'pending' : h.won ? 'won' : 'lost'}`}>
                    <span className="av-my-h-time">{h.time || ''}</span>
                    <span className="av-my-h-amt">₨{Number(h.amount).toLocaleString()}</span>
                    {h.pending ? (
                      <span className="av-my-h-mult" style={{ color: 'rgba(255,214,0,0.6)' }}>playing</span>
                    ) : h.won ? (
                      <>
                        <span className="av-my-h-mult" style={{ color: 'var(--green)' }}>{(h.mult || 0).toFixed(2)}x</span>
                        <span className="av-my-h-profit" style={{ color: 'var(--green)' }}>+₨{Number(h.profit).toLocaleString()}</span>
                      </>
                    ) : (
                      <span className="av-my-h-profit" style={{ color: 'var(--red)' }}>-₨{Number(h.amount).toLocaleString()}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </>
  )
}
